In today�s world a lot of things have been easy to access due to the web ;from education to shopping. 
especially ecommerce field which is growing very rapidly .
ompanies like Amazon ,alibaba made the shopping  experience accessible .
but still In Ethiopia there are issues people who work most of the time can�t have time to do stuff one of them being shopping .
so my aim while doing this project is make the  shopping experience  accessible  for those people while surfing the web. 
My main target groups while creating the project is for emerging companies to promote their products, local sellers, buyer ,big companies that need a bigger revenue .

